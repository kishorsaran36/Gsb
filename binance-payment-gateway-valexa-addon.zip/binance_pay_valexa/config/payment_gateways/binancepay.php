<?php

return [
	"name" => "binancepay",
	"url" => "https://pay.binance.com/",
	"class" => "BinancePay",
	"slug" => "binancepay",
	"fields" => [
		"enabled" => [
			"type" => "toggler", 
			"validation" => "nullable|in:on", 
			"value" => ""
		],
		"icon" => [
			"type" => "hidden", 
			"validation" => "nullable|string", 
			"value" => "/assets/images/payment/binancepay.webp",
		],
		"description" => [
			"type" => "hidden", 
			"validation" => "nullable|string", 
			"value" => "Credit/Debit cards, bank transfer, bank deposit, P2P, Simplex, Banxa, Paxos, ...",
		],
		"order" => [
			"type" => "hidden", 
			"validation" => "nullable|numeric", 
			"value" => null,
		],
		"mode" => [
			"type" => "dropdown", 
			"validation" => "nullable|string|in:live,sandbox|required_with:gateways.binancepay.enabled", 
			"value" => "sandbox", 
			"multiple" => 0,
			"options" => ["sandbox" => "Sandbox", "live" => "Live"]
		],
		"goods_type" => [
			"type" => "dropdown", 
			"validation" => "nullable|string|required_with:gateways.binancepay.enabled", 
			"value" => "sandbox", 
			"multiple" => 0,
			"options" => ["01" => "Tangible Goods", "02" => "Virtual Goods"]
		],
		"goods_category" => [
			"type" => "dropdown", 
			"validation" => "nullable|string|required_with:gateways.binancepay.enabled", 
			"value" => "sandbox", 
			"multiple" => 0,
			"options" => [
				"0000" => "Electronics & Computers",
				"1000" => "Books, Music & Movies",
				"2000" => "Home, Garden & Tools",
				"3000" => "Clothes, Shoes & Bags",
				"4000" => "Toys, Kids & Baby",
				"5000" => "Automotive & Accessories",
				"6000" => "Game & Recharge",
				"7000" => "Entertainament & Collection",
				"8000" => "Jewelry",
				"9000" => "Domestic service",
				"A000" => "Beauty care",
				"B000" => "Pharmacy",
				"C000" => "Sports & Outdoors",
				"D000" => "Food, Grocery & Health products",
				"E000" => "Pet supplies",
				"F000" => "Industry & Science",
				"Z000" => "Others"
			]
		],
		"api_key" => [
			"type" => "string", 
			"validation" => "nullable|string|max:255|required_with:gateways.binancepay.enabled", 
			"value" => null
		],
		"secret_key" => [
			"type" => "string", 
			"validation" => "nullable|string|max:255|required_with:gateways.binancepay.enabled", 
			"value" => null
		],
		"fee" => [
			"type" => "string", 
			"validation" => "nullable|numeric|gte:0|max:255", 
			"value" => null
		],
		"minimum" => [  // The minimum amount to pay to "Pay what you want"
			"type" => "string", 
			"validation" => "nullable|numeric|gte:0|max:255", 
			"value" => null
		],
		"auto_exchange_to" => [ // Auto-exchange Currency to This currency when using multiple currencies
			"type" => "string", 
			"validation" => "nullable|string|max:10", 
			"value" => null
		] 
	],
	"form" => [
    "inputs" => [
      "cart" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
      "subscription_id" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
      "prepaid_credits_pack_id" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
      "processor" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
      "coupon" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
      "locale" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
      "_token" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
      "checkout_token" => ["type" => "hidden", "label" => null, "value" => "", "class" => "d-none", "replace" => []],
    ],
    "note" => [],
    "checkout_buttons" => []
  ],
	"methods_icons" => [
		"btc.png" => "BTC",
		"eth.png" => "ETH",
		"usdt.png" => "USDT",
		"ltc.png" => "LTC",
	],
	"assets" => [],
	"guest_checkout" => 1,
	"async" => 0,
	"supports_recurrent" => 0,
	"webhook_responses" => ["success" => ["returnCode" => "SUCCESS", "returnMessage" => null], "failed" => ["returnCode" => "FAIL", "returnMessage" => null]],
];